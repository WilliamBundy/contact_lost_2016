function love.conf(t)
  t.screen.width = 1024
  t.screen.height = 768
  t.title = "Contact: Lost"
  t.author = "William Bundy"
  t.release = false -- To be changed for actual release
  t.identity = "ld26-williambundy-contactlost"
  t.url = "" -- to be changed to my ld48 page
end